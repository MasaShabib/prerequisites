# Sample CSV file format (machines.csv):
# hostname,architecture,mac_addresses,power_type,power_user,power_pass,power_driver,power_address,cipher_suite_id,power_boot_type,privilege_level,k_g
# PF9-testsrv,amd64/generic,3c:ad:3e:b5:1a:8c,ipmi,pf9,PASSWORD,LAN_2_0,172.25.1.189,3,efi,ADMIN,""
# Ensure you have a "cloud-init.yaml" file in the same directory.

