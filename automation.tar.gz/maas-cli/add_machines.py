import csv
import subprocess
import json
import time
from concurrent.futures import ThreadPoolExecutor

def get_machine_status(system_id, hostname):
    """Check the status of a machine in MAAS."""
    status_command = ["maas", "admin", "machine", "read", system_id]
    result = subprocess.run(status_command, capture_output=True, text=True)
    if result.returncode == 0:
        machine_info = json.loads(result.stdout)
        return machine_info.get("status_name", "Unknown")
    return "Unknown"

def wait_for_ready(system_id, hostname, timeout=600, interval=10):
    """Wait until the machine is in 'Ready' state."""
    elapsed_time = 0
    while elapsed_time < timeout:
        status = get_machine_status(system_id, hostname)
        print(f"Current status of {hostname}: {status}")
        if status == "Ready":
            return True
        time.sleep(interval)
        elapsed_time += interval
    print(f"Timeout waiting for machine {hostname} to be Ready.")
    return False

def create_machine(row):
    hostname = row["hostname"]
    architecture = row["architecture"]
    mac_addresses = row["mac_addresses"]
    power_type = row["power_type"]
    power_parameters = {
        "power_user": row["power_user"],
        "power_pass": row["power_pass"],
        "power_driver": row["power_driver"],
        "power_address": row["power_address"],
        "cipher_suite_id": row["cipher_suite_id"],
        "power_boot_type": row["power_boot_type"],
        "privilege_level": row["privilege_level"],
        "k_g": row["k_g"]
    }
    
    create_command = [
        "maas", "admin", "machines", "create",
        f"hostname={hostname}",
        f"architecture={architecture}",
        f"mac_addresses={mac_addresses}",
        f"power_type={power_type}",
        f"power_parameters={json.dumps(power_parameters)}"
    ]
    
    try:
        result = subprocess.run(create_command, check=True, capture_output=True, text=True)
        print(f"Successfully added {hostname}: {result.stdout}")
        response_json = json.loads(result.stdout)
        return hostname, response_json.get("system_id"), row["power_user"], row["power_pass"]
    except (subprocess.CalledProcessError, json.JSONDecodeError) as e:
        print(f"Error creating {hostname}: {str(e)}")
        return hostname, None, None, None

def configure_and_deploy(hostname, system_id, username, password):
    if not system_id:
        print(f"Skipping {hostname} due to missing system_id.")
        return
    
    if wait_for_ready(system_id, hostname):
        deploy_command = ["maas", "admin", "machine", "deploy", system_id]
        subprocess.run(deploy_command, check=True, capture_output=True, text=True)
        print(f"Deployed {hostname}")
        
        # Wait for deployment to complete before updating IPMI user
        time.sleep(60)
        update_ipmi_user(system_id, hostname, username, password)
    else:
        print(f"Skipping deployment for {hostname} as it did not reach Ready state.")

def update_ipmi_user(system_id, hostname, username, password):
    """Replace the default 'maas' user in IPMI settings after deployment."""
    power_params = json.dumps({
        "power_user": username,
        "power_pass": password
    })
    
    update_command = [
        "maas", "admin", "machine", "update", system_id,
        f"power_parameters={power_params}"
    ]
    try:
        subprocess.run(update_command, check=True, capture_output=True, text=True)
        print(f"Updated IPMI credentials for {hostname} (User: {username})")
    except subprocess.CalledProcessError as e:
        print(f"Failed to update IPMI user for {hostname}: {str(e)}")

def add_machines_from_csv(csv_file):
    with open(csv_file, mode='r') as file:
        reader = csv.DictReader(file)
        rows = list(reader)
    
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = [executor.submit(create_machine, row) for row in rows]
        results = [future.result() for future in futures]
    
    with ThreadPoolExecutor(max_workers=5) as executor:
        executor.map(lambda args: configure_and_deploy(*args), results)

if __name__ == "__main__":
    csv_filename = "machines.csv"
    add_machines_from_csv(csv_filename)

# Sample CSV file format (machines.csv):
# hostname,architecture,mac_addresses,power_type,power_user,power_pass,power_driver,power_address,cipher_suite_id,power_boot_type,privilege_level,k_g
# abd-test,amd64/generic,3c:ad:3e:b5:1a:8c,ipmi,exalt,Abcd@1234,LAN_2_0,172.25.1.189,3,efi,ADMIN,""

# The script now updates the IPMI user after deployment correctly using a JSON object.

